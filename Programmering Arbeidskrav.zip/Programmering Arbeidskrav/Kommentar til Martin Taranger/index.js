//Ville lagd array på hver kategori:
//let profileName = ['Stian', 'Robert', 'Kjetil', 'Sandra', 'Lene', 'Rita'];
//let profileAge = [23, 25, 36, 34, 24, 22];
//profilImage = ["images/man1.jpg", "images/man2.jpg", "images/man3.jpg", "images/woman1.jpg", "images/woman2.jpg", "images/woman3.jpg"] 

let profilArray  = [ //profileArray
	{
		profilNavn: "Stian",
		profilAlder: 23,
		profilBio: "Alphamale fra Oslo, ute etter en gøy kveld",
		sex: false,
		profilBilde: "images/man1.jpg",
	},
	{
		profilNavn: "Robert",
		profilAlder: 25,
		profilBio: "Egentlig ganske snill",
		sex: false,
		profilBilde: "images/man2.jpg",
	},
	{
		profilNavn: "Kjetil",
		profilAlder: 36,
		profilBio: "Nordsjøarbeider med naust",
		sex: false,
		profilBilde: "images/man3.jpg",
	},
	{
		profilNavn: "Sandra",
		profilAlder: 34,
		profilBio: "Ute etter en Vin Vin situasjon",
		sex: true,
		profilBilde: "images/woman1.jpg",
	},
	{
		profilNavn: "Lene",
		profilAlder: 24,
		profilBio: "Jordnær og glad i tur",
		sex: true,
		profilBilde: "images/woman2.jpg",
	},
	{
		profilNavn: "Rita",
		profilAlder: 22,
		profilBio: "Koden min fungerer ikke, og jeg aner ikke hvorfor",
		sex: true,  
		profilBilde: "images/woman3.jpg",
	},
];
//Ville forklart hvorfor sex:true / sex:false blir brukt.
let ageLimit = 25; //Ville satt denne på et mer sammenhengende sted, om den blir tatt i bruk.
//På linje 53 og 62 ville jeg byttet ut function med 1 for-løkke. 
function profilePrinter(htmlObject, profile) {
	htmlObject.innerHTML += `<h2>${profile.profilNavn}</h2>
    <h2>${profile.profilAlder}</h2>
    <img src='${profile.profilBilde}'>
    <h4>${profile.profilBio}</h4>`;
//Ville brukt p'tag til det som ikke er overskrift. Og h1-6 til det som er overskrift. 
}

//Ville tatt linjen som er under, på denne linjen.
function initAlleProfiler() {
	for (i = 0; i < profilArray.length; i++) {
		profilePrinter(resultat, profilArray[i]);
	}
}

//Ville tatt linjen som er under, på denne linjen.
function ageChecker(age, profiles, ageCheck) {
	if (age >= ageCheck) {
		let tmp = profiles.filter(profile => profile.profilAlder >= ageCheck);
		for (let i = 0; i < tmp.length; i++) {
			profilePrinter(forslag_resultat, tmp[i]);
		};
	} else {
		let tmp = profiles.filter(profile => profile.profilAlder < ageCheck)
		for (let i = 0; i < tmp.length; i++) {
			profilePrinter(forslag_resultat, tmp[i]);
		};
	}
}

function profileButtonClick() {
	let alder = document.getElementById("profil_alder").value;
	let male = document.getElementById("male").checked;
	let female = document.getElementById("female").checked;
    
    //Ville tatt linjen som er under, på denne linjen.
	forslag_resultat.innerHTML = "";
    //Ville tatt linjen som er under, på denne linjen. Og gitt den ett innrykk.
	if (alder === "") return forslag_resultat.innerHTML = "<h1>Legg til alder din Nepe!</h1>"
    //Ville tatt linjen som er under, på denne linjen. Og gitt den ett innrykk.
	alder = parseFloat(alder);
    //Ville tatt linjen som er under, på denne linjen. Og gitt den ett innrykk.
	if (Number.isNaN(alder)) return forslag_resultat.innerHTML = "<h1>Du vet forskjellen på tall og bokstaver sant? <br> SO GO DO IT AGAIN!</h1>"
    //Ville tatt linjen på 98 på denne linjen.
    
	if (male) {
		let tmp = profilArray.filter(profile => !profile.sex)
		ageChecker(alder, tmp, ageLimit)
	} else if (female) {
		let tmp = profilArray.filter(profile => profile.sex)
		ageChecker(alder, tmp, ageLimit)
	} else {
		forslag_resultat.innerHTML += `<h1>Venligst velg et kjønn!</h1>`
	}
}
//Ville tatt linje 110 på denne linjen.

function visLykken (){ 
	let resultat =document.getElementById('forslag_resultat') 
		resultat.innerHTML='';
	{ profilePrinter(resultat, profilArray[Math.floor(Math.random()* profilArray.length)] );
//Ville tatt linjen som er under, på denne linjen.
	}
}

//Ryddigheten er fin, ville samlet teksten så den hadde sett mer oversiktlig ut. Navngivingen er fin den å, men blander norsk og engelsk så det kan bli litt forvirringer. 
//Gjerne kommenter selv hva de forskjellige utrykkene gjør. Som for eksempel .isNan
//Syns dette var en veldig fin måte å gjennomføre arbeidskravet på, og likte veldig godt der du kunne ''checked'' om du var ute etter mann eller dame. 